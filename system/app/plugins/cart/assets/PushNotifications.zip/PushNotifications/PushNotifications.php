<?php
/*
* 2007-2016 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2016 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_'))
	exit;

class PushNotifications extends Module
{

    private $tokenAPI;
	public function __construct()
	{
		$this->name = 'PushNotifications';
		$this->tab = 'adminastration';
		$this->version = '1.0';
		$this->author = 'msaid mohamed el hadi';
		$this->need_instance = 0;

		$this->bootstrap = true;
		parent::__construct();

		$this->displayName = $this->l('Push notifications');
		$this->description = $this->l('Shows information on a product page: how many people are viewing it, the last time it was sold and the last time it was added to a cart.');
		$this->ps_versions_compliancy = array('min' => '1.6', 'max' => '1.6.99.99');
	}

	public function install()
	{
		if (!parent::install())
			return false;
		if (Shop::isFeatureActive()) {
		    Shop::setContext(Shop::CONTEXT_ALL);
		  }
		/* Default configuration values */

		return $this->registerHook('header') && $this->registerHook('productfooter') && $this->registerHook('addproduct')&& $this->registerHook('updateproduct');
	}
	public function getContent()
	{
		
 Tools::displayAsDeprecated();

        if (!Shop::isFeatureActive() || Shop::getTotalShops(false, null) < 2) {
            return null;
        }

        $tree = Shop::getTree();
        $context = Context::getContext();

        // Get default value
        $shop_context = Shop::getContext();
        if ($shop_context == Shop::CONTEXT_ALL || ($context->controller->multishop_context_group == false && $shop_context == Shop::CONTEXT_GROUP)) {
            $value = '';
        } elseif ($shop_context == Shop::CONTEXT_GROUP) {
            $value = 'g-'.Shop::getContextShopGroupID();
        } else {
            $value = 's-'.Shop::getContextShopID();
        }

        // Generate HTML
        $url = $_SERVER['REQUEST_URI'].(($_SERVER['QUERY_STRING']) ? '&' : '?').'setShopContext=';
        $shop = new Shop(Shop::getContextShopID());

        // $html = '<a href="#"><i class="icon-home"></i> '.$shop->name.'</a>';
      
        foreach ($tree as $group_id => $group_data) {
            
            if (!isset($context->controller->multishop_context) || $context->controller->multishop_context & Shop::CONTEXT_SHOP) {
                foreach ($group_data['shops'] as $shop_id => $shop_data) {
                    if ($shop_data['active']) {
                        //var_dump($shop_data);
                        $configarray[$group_id.'_'.$shop_id]=ConfigurationCore::get('ps_push_javascript_link', NULL, NULL, $shop_id);
                        $configarrayid[$group_id.'_'.$shop_id]=ConfigurationCore::get('ps_push_website_id', NULL, NULL, $shop_id);
                        $title[$group_id.'_'.$shop_id]=ConfigurationCore::get('ps_push_notification_title', NULL, NULL, $shop_id);
                        $msg[$group_id.'_'.$shop_id]=ConfigurationCore::get('ps_push_notification_msg', NULL, NULL, $shop_id);
                    }
                }
            }
        }
        $client_id=ConfigurationCore::get('ps_push_API_client_id', NULL, NULL, NULL);
        $client_secret=ConfigurationCore::get('ps_push_API_client_secret', NULL, NULL, NULL);
        if (isset($_POST['client_id'])) {
            # code...
            ConfigurationCore::updateValue('ps_push_API_client_id', $_POST['client_id']);
        }
        if (isset($_POST['client_secret'])) {
            # code...
            ConfigurationCore::updateValue('ps_push_API_client_secret', $_POST['client_secret']);
            
        }
        if (isset($_POST['inegra'])) {
            # code...

            foreach ($_POST['msg'] as $key => $value) {
                # code...
            $id_shop=$key;
            ConfigurationCore::updateValue('ps_push_notification_msg', $value, true,  NULL,  $id_shop);
            }
            foreach ($_POST['title'] as $key => $value) {
                # code...
            $id_shop=$key;
            ConfigurationCore::updateValue('ps_push_notification_title', $value, true,  NULL,  $id_shop);
            }
            foreach ($_POST['inegra'] as $key => $value) {
                # code...
            $id_shop=$key;
            ConfigurationCore::updateValue('ps_push_javascript_link', $value, true,  NULL,  $id_shop);
            }
            foreach ($_POST['inegraid'] as $key => $value) {
                # code...
            $id_shop=$key;
            ConfigurationCore::updateValue('ps_push_website_id', $value, true,  NULL,  $id_shop);
            }
        }
        
        $this->context->smarty->assign(array(
            'tree' => $tree,
            'configarray'=>$configarray,
            'configarrayid'=>$configarrayid,
            'client_id'=>$client_id,
            'client_secret'=>$client_secret,
            'title'=>$title,
            'msg'=>$msg,
             ));

        return $this->display(__FILE__,'views/admin.tpl');
	}

    public function hookHeader($params)
    {
        $this->context->shop->id;
        $this->context->controller->addJS( ConfigurationCore::get('ps_push_javascript_link', NULL, $this->context->shop->id_shop_group, $this->context->shop->id));
    }
    public function hookAddProduct($params)
    {
      
        $data = array(
            'grant_type' => 'client_credentials',
            'client_id' =>  ConfigurationCore::get('ps_push_API_client_id', NULL, NULL, NULL),
            'client_secret' => ConfigurationCore::get('ps_push_API_client_secret', NULL, NULL, NULL),
        );
        $url =  'https://api.sendpulse.com/oauth/access_token' ;
        $curl = curl_init();

        

        switch ('POST') {
            case 'POST':
                curl_setopt($curl, CURLOPT_POST, count($data));
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'DELETE');
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            default:
                if (!empty($data)) {
                    $url .= '?' . http_build_query($data);
                }
        }

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, true);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($curl, CURLOPT_TIMEOUT, 15);

        $response = curl_exec($curl);
        $header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
        $headerCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $responseBody = substr($response, $header_size);

        curl_close($curl);
       $requestResult= json_decode($responseBody);
         $access_token= $requestResult->access_token;
$taskInfo = array(
    'title' => ConfigurationCore::get('ps_push_notification_title', NULL, NULL, $params['id_shop_default']),
    'body' => ConfigurationCore::get('ps_push_notification_msg', NULL, NULL, $params['id_shop_default']),
    'website_id' => ConfigurationCore::get('ps_push_website_id', NULL, NULL, $params['id_shop_default']),
    'ttl' => 20,
    'stretch_time' => 10,
);
// This is optional
//$additionalParams = array(
 //   'link' => 'http://yoursite.com',
//);
$data = $taskInfo;
        if (!isset($data['ttl'])) {
            $data['ttl'] = 0;
        }
        
        if ($additionalParams) {
            foreach ($additionalParams as $key => $val) {
                $data[$key] = $val;
            }
        }


        $url =  'https://api.sendpulse.com/push/tasks';
        $curl = curl_init();

        if (!empty($access_token)) {
            $headers = array('Authorization: Bearer ' . $access_token);
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        }

        switch ('POST') {
            case 'POST':
                curl_setopt($curl, CURLOPT_POST, count($data));
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'DELETE');
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            default:
                if (!empty($data)) {
                    $url .= '?' . http_build_query($data);
                }
        }

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, true);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($curl, CURLOPT_TIMEOUT, 15);

        $response = curl_exec($curl);
        $header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
        $headerCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $responseBody = substr($response, $header_size);

        curl_close($curl);
        ConfigurationCore::updateValue('ps_test_vardump', $access_token);
    }

    public function hookUpdateProduct($params)
    {
           
     
        $data = array(
            'grant_type' => 'client_credentials',
            'client_id' =>  ConfigurationCore::get('ps_push_API_client_id', NULL, NULL, NULL),
            'client_secret' => ConfigurationCore::get('ps_push_API_client_secret', NULL, NULL, NULL),
        );
        $url =  'https://api.sendpulse.com/oauth/access_token' ;
        $curl = curl_init();

        

        switch ('POST') {
            case 'POST':
                curl_setopt($curl, CURLOPT_POST, count($data));
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'DELETE');
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            default:
                if (!empty($data)) {
                    $url .= '?' . http_build_query($data);
                }
        }

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, true);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($curl, CURLOPT_TIMEOUT, 15);

        $response = curl_exec($curl);
        $header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
        $headerCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $responseBody = substr($response, $header_size);

        curl_close($curl);
       $requestResult= json_decode($responseBody);
         $access_token= $requestResult->access_token;
$taskInfo = array(
    'title' => ConfigurationCore::get('ps_push_notification_title', NULL, NULL, $params['id_shop_default']),
    'body' => ConfigurationCore::get('ps_push_notification_msg', NULL, NULL, $params['id_shop_default']),
    'website_id' => ConfigurationCore::get('ps_push_website_id', NULL, NULL, $params['id_shop_default']),
    'ttl' => 20,
    'stretch_time' => 10,
);
// This is optional
//$additionalParams = array(
 //   'link' => 'http://yoursite.com',
//);
$data = $taskInfo;
        if (!isset($data['ttl'])) {
            $data['ttl'] = 0;
        }
        
        if ($additionalParams) {
            foreach ($additionalParams as $key => $val) {
                $data[$key] = $val;
            }
        }


        $url =  'https://api.sendpulse.com/push/tasks';
        $curl = curl_init();

        if (!empty($access_token)) {
            $headers = array('Authorization: Bearer ' . $access_token);
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        }

        switch ('POST') {
            case 'POST':
                curl_setopt($curl, CURLOPT_POST, count($data));
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'PUT':
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'PUT');
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            case 'DELETE':
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'DELETE');
                curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
                break;
            default:
                if (!empty($data)) {
                    $url .= '?' . http_build_query($data);
                }
        }

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, true);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($curl, CURLOPT_TIMEOUT, 15);

        $response = curl_exec($curl);
        $header_size = curl_getinfo($curl, CURLINFO_HEADER_SIZE);
        $headerCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $responseBody = substr($response, $header_size);

        curl_close($curl);
        ConfigurationCore::updateValue('ps_test_vardump', $access_token);
   
    }
 
}