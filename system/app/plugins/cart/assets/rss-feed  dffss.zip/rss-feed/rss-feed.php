<?php 
/*
Plugin Name:  rss Feed
Plugin URI: 
Version: 1.0
Author: mohamedgb00714@gmail.com
Description: creat articles from http://www.mosr.sk/rss/ 
*/

/**
 * UltraVid CRON shortcode
 */
function UltraVider_create_tables(){
		global $wpdb;
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	$sql = "

        CREATE TABLE {$wpdb->prefix}rss_post (

        id bigint(20) NOT NULL auto_increment,


        url text NULL,


        

        PRIMARY KEY  (id)

        ) $charset_collate;

        ";



	dbDelta($sql);


}
register_activation_hook(__FILE__, 'UltraVider_create_tables');
add_shortcode('UltraVidCron', 'UltraVid_shortcode_cron_func');

function UltraVid_shortcode_cron_func( $atts ){
	global $wpdb;
    $atts = shortcode_atts( array(
        'id'                => '0'
    ), $atts, 'UltraVidCron' );
    
    
    $chanes=$wpdb->get_results("SELECT * FROM {$wpdb->prefix}rss_post");

    if (sizeof($chanes)==0) {
    	# code...
     $wpdb->insert( 
                	"{$wpdb->prefix}rss_post", 
                	array( 
                		'id' =>'1', 
                		'url' => 'now'
                		)
                );
//$wpdb->show_errors();
                    }
    set_time_limit(0);
    ob_start();
    UltraVider_autopost_cron($chanes[0]->url);
	echo 'die';
    $content = ob_get_clean();
    
    return $content;
}

function UltraVider_autopost_cron($lasturl)
{
	global $wpdb ;
 	// var_dump($chanes);  
	 $errors = array();
	 $post_category=0;
 //$homepage = file_get_contents('http://www.mosr.sk/rss/');
  $curl = curl_init();
curl_setopt_array($curl, array(
     CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_FOLLOWLOCATION =>true,
     CURLOPT_HTTPHEADER => array(
    'X-Apple-Tz: 0',
    'X-Apple-Store-Front: 143444,12'
    ),
     CURLOPT_USERAGENT=>"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36",
    CURLOPT_URL => 'http://www.mosr.sk/rss/'
));
$homepage = curl_exec($curl);


$xml = simplexml_load_string($homepage);
$json = json_encode($xml);
$array = json_decode($json,TRUE);
//var_dump($array['channel']["item"]);
$url=$array['channel']["item"][0]['link'];
	 $wpdb->query("UPDATE  {$wpdb->prefix}rss_post SET url = '$url' WHERE id = 1");
// var_dump();

foreach ($array['channel']["item"] as $key => $value) {
	# code...


		
	if ($value['link']==$lasturl) {
		break;
	}

	 $curl = curl_init();
curl_setopt_array($curl, array(
     CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_FOLLOWLOCATION =>true,
     CURLOPT_HTTPHEADER => array(
    'X-Apple-Tz: 0',
    'X-Apple-Store-Front: 143444,12'
    ),
     CURLOPT_USERAGENT=>"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36",
    CURLOPT_URL => $value['link']
));
$html = curl_exec($curl);

$pattern = "/<img ?.*class=\"rounded\"(.*)\/>/";
    preg_match($pattern, $html, $matches);

$pattern = "/src=\"(.*)\" alt/";
    preg_match($pattern, $matches[0], $matches1);
$image_url='http://www.mosr.sk'.$matches1[1];
$image_url=str_replace('" width="350', '', $image_url);
echo $image_url;
echo "<br>";
$classname = 'wnews_sprava';
$dom = new DOMDocument;
libxml_use_internal_errors(true);
$dom->loadHTML($html);
libxml_use_internal_errors(false);
$xpath = new DOMXPath($dom);
$results = $xpath->query("//*[@class='" . $classname . "']");
if ($results->length > 0) {
    $review = DOMinnerHTML($results->item(0));
    $pattern = "/<img (.*)/>";
    $replacement='';
     $review=preg_replace($pattern, $replacement,$review);
    $pattern = "/<a(.*) rel=\"foto\">/";
    $replacement=' ';
     $review=preg_replace($pattern, $replacement,$review);
    $review=str_replace('<span class="more">Galéria</span>', '', $review);
    $review=str_replace('</a>', '', $review);
     
}
	
		// do save campaign
		

    


                    // add post


	// Gather post data.
	$post_title=$value['title'];
$my_post = array(
    'post_title'    => $post_title ,
    'post_content'  => $review,
    'post_author'   => 1,
    'post_category' => array( 152 ),
    'post_status'       =>  'publish'
);

// Insert the post into the database.
$post_id = wp_insert_post( $my_post );
// wp_set_post_tags( $post_id, $_POST['tags'], true );
// var_dump($_POST);
 $thumbnail_id =uploadRemoteImageAndAttachUltraVid($image_url, $post_id);
echo $thumbnail_id;
if( ! is_wp_error( $post_id ) )       update_post_meta( $post_id, '_thumbnail_id', $thumbnail_id );


          
 
 
$post_date = get_the_date( "Y-m-d",$post_id );
 $src = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), 'full', false );


		}

	
	

}
		function uploadRemoteImageAndAttachUltraVid($image_url, $parent_id){

    $image = $image_url;

    $get = wp_remote_get( $image );

    $type = wp_remote_retrieve_header( $get, 'content-type' );

    if (!$type)
        return false;
$image1=explode('.jpg', $image) ;
    $mirror = wp_upload_bits( basename( $image1[0].'.jpg' ), '', wp_remote_retrieve_body( $get ) );

    $attachment = array(
        'post_title'=> basename( $image ),
        'post_mime_type' => $type
    );

    $attach_id = wp_insert_attachment( $attachment, $mirror['file'], $parent_id );

    require_once(ABSPATH . 'wp-admin/includes/image.php');

    $attach_data = wp_generate_attachment_metadata( $attach_id, $mirror['file'] );

    wp_update_attachment_metadata( $attach_id, $attach_data );

    return $attach_id ;

}


function DOMinnerHTML(DOMNode $element) 
{ 
    $innerHTML = ""; 
    $children  = $element->childNodes;

    foreach ($children as $child) 
    { 
        $innerHTML .= $element->ownerDocument->saveHTML($child);
    }

    return $innerHTML; 
} 

 ?>